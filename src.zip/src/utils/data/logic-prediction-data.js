export const DESIGNTYPE = [{ id: 1, name: "or1200_top", value: "or1200_top" }];

export const BEOLTYPE = [
  { id: 1, name: "7M_2Mx_3Cx_1Ix_1Ox_LB", value: "7M_2Mx_3Cx_1Ix_1Ox_LB" },
  { id: 2, name: "8M_2Mx_4Cx_1Ix_1Ox_LB", value: "8M_2Mx_4Cx_1Ix_1Ox_LB" },
];

export const PROCESSTYPE = [{ id: 1, name: "22FDSOI", value: "22FDSOI" }];

export const BIASTYPE = [
  { id: 1, name: "ZBB", value: "ZBB" },
  { id: 2, name: "FBB", value: "FBB" },
];

export const TRACKTYPE = [{ id: 1, name: "6.75T", value: "6.75T" }];
